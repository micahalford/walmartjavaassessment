package com.example.javapart2fe;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import java.util.regex.Pattern;

public class Login extends AppCompatActivity implements View.OnClickListener{

    private static final Pattern PASSWORD_PATTERN =
            Pattern.compile("^" +
                    "(?=.*[A-Z])" +      // 1 or more uppercase required
                    "(?=.*[@#$%^&+=])" + // 1 or more special char required
                    "(?=\\S+$)" +        // NO white space
                    ".{8,}" +            // Minimum 8 characters
                    "$");
    Button bLogin;
    EditText etUsername, etPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etUsername = findViewById(R.id.et_Username);
        etPassword = findViewById(R.id.et_Password);
        bLogin = findViewById(R.id.b_Login);

        bLogin.setOnClickListener(this); // Listen for login button click
    }

    private boolean validateUsername() {
        String usernameInput = etUsername.getText().toString().trim(); // Provide feedback for
                                                                       // an empty username field
        if (usernameInput.isEmpty()) {
            etUsername.setError("Field can not be empty");
            return false;
        } else {
           etUsername.setError(null);
            return true;
        }
    }

    private boolean validatePassword() {
        String passwordInput = etPassword.getText().toString().trim();

        if (passwordInput.isEmpty()) {
            etPassword.setError("Field can't be empty"); // Provide feedback for empty password field
            return false;
        } else if (!PASSWORD_PATTERN.matcher(passwordInput).matches()) {
            etPassword.setError("Must contain 8 characters including " + // Provide feedback for
                    "1 special character and 1 uppercase letter");       // password not containing
            return false;                                                // required entry
        } else {
            etPassword.setError(null);
            return true;
        }
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.b_Login:                                  // Do not proceed if password
                if(!validateUsername() | !validatePassword()) { // or username empty,
                } else {
                    startActivity(new Intent(this, SwipeView.class)); // Proceed
                    break; }

        }
    }
}
