/*
Exhausted resources in an attempt to complete this section of the Assessment. Unsure what is
causing the issue, but the app continues to crash when adding other formatting tools to the
layout_listview.xml file. Attempting to implement images such as drawable_walmart
or a swipe-for-delete-button caused immediate crashing.
*/

package com.example.javapart2fe;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class SwipeView extends AppCompatActivity {
    String[] exampleArray = // Establishing array of example list items
            {"Example 1","Example 1","Example 1","Example 1",
             "Example 1","Example 1","Example 1","Example 1",
             "Example 1", "Example 1", "Example 1"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_swipe_view);
        ArrayAdapter adapter = new ArrayAdapter<String>(this,
                R.layout.layout_listview, exampleArray);
        ListView listView = (ListView) findViewById(R.id.example_list); // Setting list view
        listView.setAdapter(adapter);
    }
}
