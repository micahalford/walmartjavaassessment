import java.util.HashMap;
import java.util.Map.Entry;

public class JavaPart3 {
    /*
    Write a function in Java 8 that accepts a given string and returns the number of times
    each word is repeated. Return the data in this format: [{"team": 1}, {"only": 1}]
    */
    public static void main(String[] args) {

        int count = 0; // Initialize count to 0

        // Declare string variable from PDF
        String phrase = "Walmart Technology is reinventing the way the world shops and we've only just begun."
                + " Our team includes @Walmart Labs in Silicon Valley and Bengaluru, which powers the eCommerce"
                + " experience, as well as technology teams across data and analytics, retail, back office,"
                + " and more who help power store and digital experiences. The best thing about Walmart is its"
                + " rich history!"; // Provided string

        // Stored in an array; use .split and replace non-essential special characters
        String[] phraseArray = phrase.replaceAll("[!,.]", "").split(" ");

        // Establish HashMap from java.util.HashMap
        HashMap<String, Integer> freqMap = new HashMap<String, Integer>();

        // For loop to scroll through array and pull keys and values
        for (int i = 0; i < phraseArray.length; i++) {
            String key = phraseArray[i];
            int freq = freqMap.getOrDefault(key, 0);
            freqMap.put(key, ++freq);
        }
        // For loop to print results as a string
        for (Entry<String, Integer> result : freqMap.entrySet()) {
            System.out.print("{\"" + result.getKey() + "\": " + result.getValue() + "} ");
        }
    }
}
