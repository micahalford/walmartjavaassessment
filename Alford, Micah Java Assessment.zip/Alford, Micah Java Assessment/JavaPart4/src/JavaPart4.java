import java.util.Arrays;

public class JavaPart4 {

    public static void main(String[] args) {

        // Establish Arrays, both String and Boolean
        String[]  activeStatus   = new String[]  {"Smith", "Brown"};
        String[]  fName          = new String[]  {"John", "John", "John", "John"};
        String[]  address        = new String[]  {"100 N. Main", "100 N. Main", "100 N. Main", "100 N. Main"};
        String[]  phone          = new String[]  {"+1-(123)-456-7890", "+1-(123)-456-7890", "+1-(123)-456-7890", "+1-(123)-456-7890"};
        String[]  lName          = new String[]  {"Smith", "Doe", "Brown", "Akins"};
        boolean[] status         = new boolean[] {false, false, false, false};

        // Sort Last Names
        Arrays.sort(lName);

        // Set active status for each name, checking with names in activeStatus array
        for(int i = 0; i <=3; i++) {
            if(lName[i].equals(activeStatus[0]) || lName[i].equals(activeStatus[1]))
                status[i] = true;
        }

        // Print loop
        for(int i = 0; i <=3; i++) {
            System.out.println("Name: "    + fName[i] + " " + lName[i]);
            System.out.println("Address: " + address[i]);
            System.out.println("Phone: "   + phone[i]);
            System.out.println("Active: "  + status[i]);
            System.out.println(" ");
        }
    }
}